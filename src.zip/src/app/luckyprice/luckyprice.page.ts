import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, MenuController, ActionSheetController, LoadingController, AlertController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { ItemService } from 'src/app/services/item.service';
import { AlertService } from 'src/app/services/alert.service';
import { EnvService } from 'src/app/services/env.service';
import { LuckyService } from 'src/app/services/lucky.service';
import { LuckyPage } from '../modals/lucky/lucky.page';

@Component({
  selector: 'app-luckyprice',
  templateUrl: './luckyprice.page.html',
  styleUrls: ['./luckyprice.page.scss'],
})
export class LuckypricePage implements OnInit {
	luckyPrices:any;
	constructor(private modalController: ModalController, private navCtrl: NavController, private menu: MenuController,private itemService: ItemService,private alertService: AlertService,private router: Router, private env:EnvService, public actionSheetController: ActionSheetController, public loadingController: LoadingController, public alertController: AlertController, public luckyService:LuckyService){
		this.menu.enable(true);
	}

	ngOnInit(){
		this.presentLoading();
		this.luckyService.luckpriceLists().subscribe(data=>{
			this.luckyPrices =data['luckyPriceList'];
			this.presentLoadingDismiss();
		});
	}

	async newLuckyModal() {
		const modal = await this.modalController.create({
			component: LuckyPage,
			cssClass: "luck-Modal"
		});
		modal.onDidDismiss().then((response) => {
			if(response.data.data != ''){
				this.alertService.presentToast(response.data.data);
				this.ngOnInit();
			}
			console.log("Modal Closed.");
		});
		return await modal.present();
	}

	async presentLoading() {
		const loading = await this.loadingController.create({
			message: 'Please wait...',
			//duration: 2000
		});
		await loading.present();
	}

	async presentLoadingDismiss(){
		await this.loadingController.dismiss();
	}
}
