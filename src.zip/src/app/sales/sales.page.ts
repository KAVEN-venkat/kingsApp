import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, MenuController, ActionSheetController, LoadingController, AlertController } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { OrderService } from 'src/app/services/order.service';
import { ItemService } from 'src/app/services/item.service';
import { AlertService } from 'src/app/services/alert.service';
import { EnvService } from 'src/app/services/env.service';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.page.html',
  styleUrls: ['./sales.page.scss'],
})
export class SalesPage implements OnInit {
	orders=[];
	itemName:String;
	constructor(private modalController: ModalController, private navCtrl: NavController, private menu: MenuController,private orderService: OrderService,private alertService: AlertService,private router: Router, private env:EnvService, public actionSheetController: ActionSheetController, public loadingController: LoadingController, public alertController: AlertController, private itemService: ItemService){
		this.menu.enable(true);
	}

	ngOnInit() {
		this.ordersList();
	}
	
	ordersList(){
		this.presentLoading();
		let limit = 'all';
		this.orderService.orderLists(limit).subscribe(data => {
	    	//console.log(data);
	    	//let result = JSON.stringify(data);
	    	this.presentLoadingDismiss();
	    	if(data['status']){
	    	this.orders = data['ordersList'];
		    console.log(this.orders);
			}else{
		    	this.alertService.presentToast(data['message']);
	    	}
	    },error => {
	        console.log(error);
	    });
	}
	itemByColumn(itemId,columnName){
		this.itemService.itemByColumn(itemId,columnName).subscribe(data => {
	    	console.log(data);
	    	if(data['status']){
	    		this.itemName = data['items'];
			}else{
		    	this.alertService.presentToast(data['message']);
	    	}
	    },error => {
	        console.log(error);
	    });
	}
	
	async newSaleModal() {
		this.navCtrl.navigateRoot('/sale');
	}

	async presentLoading() {
		const loading = await this.loadingController.create({
			message: 'Please wait...',
			//duration: 2000
		});
		await loading.present();
	}

	async presentLoadingDismiss(){
		await this.loadingController.dismiss();
	}
}
