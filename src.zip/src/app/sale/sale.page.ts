import { Component, OnInit, Input, ViewChild,ElementRef } from '@angular/core';
import { ModalController, NavController, MenuController, ActionSheetController, LoadingController, AlertController,ToastController } from '@ionic/angular';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, NavigationExtras } from '@angular/router';
import { BluetoothSerial } from '@ionic-native/bluetooth-serial/ngx';
import { CategoryService } from 'src/app/services/category.service';
import { ItemService } from 'src/app/services/item.service';
import { AlertService } from 'src/app/services/alert.service';
import { EnvService } from 'src/app/services/env.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-sale',
  templateUrl: './sale.page.html',
  styleUrls: ['./sale.page.scss'],
})
export class SalePage implements OnInit {
	@ViewChild('qtyFocus') inputElementQty;
	@ViewChild('fromFocus') inputElementFrom;
	@ViewChild('toFocus')  inputElementTo;
	saleForm: FormGroup;
	submitted = false;
	categories:String;
	items=[];
	currentDate: String = new Date().toISOString();
	item_qty: any;
	customer_id:any;
	item_id:any;
	itemName: any;
	itemPrice: any;
	extraPrice:any;
	min_length: any;
	max_length: any;
	orders: Array<{ id:Number,sale_date:Date,category_id:Number,item_id:Number,item_price:any,extra_price:any,item_digits:String,item_number:any,item_qty:Number,total_items:Number,total_price:any,created_by:Number,created_at:Date,updated_at:Date,delete_at:Date,item:any }> = [];
	

	constructor(private modalController: ModalController, private navCtrl: NavController, private menu: MenuController,private categoryService: CategoryService, private orderService: OrderService,private alertService: AlertService,private router: Router, private env:EnvService, public actionSheetController: ActionSheetController, public loadingController: LoadingController, public alertController: AlertController,private itemService: ItemService, private formBuilder: FormBuilder,private bluetoothSerial: BluetoothSerial,private toastCtrl: ToastController){
		this.menu.enable(true);
	}

	ngOnInit() {
		if(!localStorage.getItem('user_id')){
			this.navCtrl.navigateRoot('/');
		}
		this.categoriesList();
		//this.itemsList();
		this.saleFormValidation();	
	}

	focusOnQty() {
    	setTimeout(() => {
        	this.inputElementQty.setFocus();
    	}, 200);
	}
	focusOnFrom() {
    	setTimeout(() => {
        	this.inputElementFrom.setFocus();
    	}, 200);
  	}
	removeText() {
		this.saleForm.controls['item_to'].setValue('');
	}
	saleFormValidation() {
		this.saleForm = this.formBuilder.group({
            sale_date: [this.currentDate, Validators.required],
            category_id: ['', Validators.required],
            item_id: ['', Validators.required],
            item_from: ['', Validators.required],
            item_to: ['', Validators.required],
            item_digits: ['C', Validators.required],
            item_qty: [this.item_qty, Validators.required],
        });
	}

	categoriesList(){
		this.categoryService.categories().subscribe(data => {
	    	if(data['status']){
	    	this.categories = data['categoriesList'];
		    console.log(this.categories);
			}else{
		    	this.alertService.presentToast(data['message']);
	    	}
	    },error => {
	        console.log(error);
	    });
	}

	/*itemsList(){
		//this.presentLoading();
		this.itemService.items().subscribe(data => {
	    	if(data['status']){
	    		//this.presentLoadingDismiss();
		    	this.items = data['itemsList'];
			    console.log(this.items);
			}else{
		    	this.alertService.presentToast(data['message']);
	    	}
	    },error => {
	        console.log(error);
	    });
	}*/
	getItemByCategory(event) {
		//;
		if(event.detail.value != ''){		
			this.itemService.itemByCategory(event.detail.value).subscribe(data => {
		    	console.log(data);
		    	//this.presentLoadingDismiss();
		    	if(data['status']){
		    		this.items = data['itemDetails'];
				}else{
			    	this.alertService.presentToast(data['message']);
		    	}
		    },error => {
		        console.log(error);
		    });
		}
	}
	getItemId(event) {
		this.item_id = event.detail.value;
		if(this.item_id != ''){	
		//this.presentLoading();	
			this.itemService.item(event.detail.value).subscribe(data => {
		    	console.log(data);
		    	//this.presentLoadingDismiss();
		    	if(data['status']){
		    		this.itemName = data['itemDetails'].item_name;
		    		this.itemPrice = data['itemDetails'].item_price;
		    		this.min_length = data['itemDetails'].item_digits;
		    		this.max_length = data['itemDetails'].item_digits;
		    		console.log(parseFloat(this.itemPrice) + parseFloat(this.extraPrice));
					this.saleForm.controls['item_from'].setValue('');
					this.saleForm.controls['item_to'].setValue('');
					//this.saleForm.controls['item_qty'].setValue('');
				}else{
			    	this.alertService.presentToast(data['message']);
		    	}
		    },error => {
		        console.log(error);
		    });
		}
	}

	getItemFrom(event) {
		if (event.detail.value != '') {
			this.saleForm.controls['item_to'].setValue(event.detail.value);
		}
		if (this.max_length == event.detail.value.length) {
			//alert(event.detail.value.length);
			this.focusOnQty();
		}
	}
	getItemTo(event) {
		if (this.max_length == event.detail.value.length) {
			this.saleForm.controls['item_qty'].setValue('');
			this.focusOnQty();
		}
	}
	newSale() {
		this.submitted = true;
		if (this.saleForm.invalid) {
			return;
		}
		this.orderService.createOrder(this.saleForm.value.category_id, this.extraPrice, this.saleForm.value.item_digits, this.saleForm.value.item_from, this.saleForm.value.item_id, this.itemPrice, this.saleForm.value.item_qty, this.saleForm.value.item_to, this.saleForm.value.sale_date, this.max_length).subscribe(data => {
			if (data['status'] == 1) {
				data['orderDetails'].forEach(order => {
					this.orders.push({ id:order.id,sale_date:order.sale_date,category_id:order.category_id,item_id:order.item_id,item_price:order.item_price,extra_price:order.extra_price,item_digits:order.item.item_digits,item_number:order.item_number,item_qty:order.item_qty,total_items:order.total_items,total_price:order.total_price,created_by:order.created_by,created_at:order.created_at,updated_at:order.updated_at,delete_at:order.delete_at,item:order.item });
				});
			}
			console.log("Order List");
			console.log(this.orders);
			this.saleForm.controls['item_from'].setValue('');
			this.saleForm.controls['item_to'].setValue('');
			this.saleForm.controls['item_qty'].setValue('');
			this.focusOnFrom();
	    },error => {
	        console.log(error);
	    });
	}

	async viewSale() {
		this.navCtrl.navigateRoot('/sales');
	}

	async presentLoading() {
		const loading = await this.loadingController.create({
			message: 'Please wait...',
			//duration: 2000
		});
		await loading.present();
	}

	async presentLoadingDismiss(){
		await this.loadingController.dismiss();
	}

	async removeOrder(index,orderId,itemNumber) {
		const alert = await this.alertController.create({
			cssClass: 'my-custom-class',
			header: 'Confirmation!',
			message: 'Are you sure want to delete <strong>'+itemNumber+'</strong>?',
			buttons: [
			{
				text: 'Cancel',
				role: 'cancel',
				cssClass: 'secondary',
				handler: (blah) => {
					console.log('Confirm Cancel: blah');
				}
			}, {
				text: 'Yes',
				handler: () => {
					this.deleteOrder(index,orderId,itemNumber);
				}
			}
			]
		});
    	await alert.present();
	}
	deleteOrder(index,orderId,itemNumber){
		// var isPresent = this.orders.some(function (order, i) {
		// 	return order.id === orderId;
		// });
		// console.log(isPresent);
		let i = this.orders.indexOf(index);
		if(i > -1){
			this.orders.splice(i, 1);
			this.orderService.deleteOrder(orderId).subscribe(data => {
				if(data['status']){
				this.alertService.presentToast(data['message']);
				//this.categoriesList();
				}else{
					this.alertService.presentToast(data['message']);
				}			
			},error => {
				console.log(error);
			});
		}
	}
	async showError(error){
		let alert = await this.alertController.create({
			header: 'Error',
	      	subHeader: error,
	      	buttons: ['Dismiss']
		});
		await alert.present();
	}
	async showToast(msg){
		const toast = await this.toastCtrl.create({
			message:msg,
			duration: 1000
		});
		toast.present();
	}
	checkBluetooth() {
		this.bluetoothSerial.isEnabled().then(success => {
			console.log(success);
			if (success == 'OK') {
				this.printOrder();
			}
		},error => {
			this.showError("Please Enable Bluetooth");
		});
	}
	printOrder() {
		if (this.orders && this.orders.length > 0) {
			for (let i = 0; i < this.orders.length; i++) {
				let dataSend = this.orders[i].sale_date + ' \t\t\t\t\t\n ' + this.orders[i].item_number + ' - ' + ' \t\t\t\t\t ' + this.orders[i].total_items + ' - ' + this.orders[i].total_price + ' \n';
				this.showToast(dataSend);
				this.bluetoothSerial.write(dataSend).then(success => {
					this.showToast(success);
					this.navCtrl.navigateRoot('/sales');
				}, error => {
					this.showError(error);
				});
			}
		}
	}
}
