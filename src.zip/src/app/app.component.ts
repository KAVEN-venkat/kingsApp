import { Component, OnInit } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { ModalController, MenuController, NavController } from '@ionic/angular';
import { WelcomePage } from './welcome/welcome.page';

import { UniqueDeviceID } from '@ionic-native/unique-device-id/ngx';
import { Uid } from '@ionic-native/uid/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  public selectedIndex = 0;
  public appPages = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'Categories',
      url: '/categories',
      icon: 'people'
    },
    {
      title: 'Items',
      url: '/ticket',
      icon: 'bookmark'
    },
    /*{
      title: 'Customers',
      url: '/user',
      icon: 'people'
    },*/
    {
      title: 'Sale',
      url: '/sale',
      icon: 'briefcase'
    },
    {
      title:'Schemes',
      url:'/luckyprice',
      icon:'trophy'
    },
    {
      title:'Result',
      url:'/winners',
      icon:'trophy'
    },
    {
      title:'Statement',
      url:'/result',
      icon:'documents'
    },
    {
      title: 'Settings',
      url: '/settings',
      icon: 'settings'
    }
    /*{
      title: 'Inbox',
      url: '/folder/Inbox',
      icon: 'mail'
    },
    {
      title: 'Outbox',
      url: '/folder/Outbox',
      icon: 'paper-plane'
    },
    {
      title: 'Favorites',
      url: '/folder/Favorites',
      icon: 'heart'
    },
    {
      title: 'Archived',
      url: '/folder/Archived',
      icon: 'archive'
    },
    {
      title: 'Trash',
      url: '/folder/Trash',
      icon: 'trash'
    },
    {
      title: 'Spam',
      url: '/folder/Spam',
      icon: 'warning'
    }*/
  ];
  //public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
  UniqueDeviceID:string;
  userName:string;
  email:string;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private navCtrl: NavController,
    private menuCtrl: MenuController,
    private uniqueDeviceID: UniqueDeviceID,
    private uid: Uid,
    private androidPermissions: AndroidPermissions
  ) {
    this.initializeApp();
  }

  initializeApp() {
      this.userName = localStorage.getItem('first_name')+" "+localStorage.getItem('last_name');
      this.email = localStorage.getItem('email');
    this.platform.ready().then(() => {
      if(!localStorage.getItem('user_id')){
        this.navCtrl.navigateRoot('/');
      }else{
        this.navCtrl.navigateRoot('/home');
      }
      if (this.platform.is('android')) {
          console.log("running on Android device!");
      }
      if (this.platform.is('ios')) {
          console.log("running on iOS device!");
      }
      if (this.platform.is('mobileweb')) {
          console.log("running in a browser on mobile!");
      }
      this.getPermission();
      this.getUniqueDeviceID();
      
      this.statusBar.styleDefault();
      this.splashScreen.hide();

      this.platform.backButton.subscribe(()=>{
        console.log ('exit:-'+window.location.pathname);
        if (window.location.pathname == "/login" || window.location.pathname == "/otp" || window.location.pathname == "/register") {
            this.navCtrl.navigateRoot('/');
          }else if (window.location.pathname == "/forgot" || window.location.pathname == "/reset") {
            this.navCtrl.navigateRoot('/login');
          }else{
            navigator['app'].exitApp();
          }      
      });
    });
  }

  ngOnInit() {
    const path = window.location.pathname.split('folder/')[1];
    if (path !== undefined) {
      this.selectedIndex = this.appPages.findIndex(page => page.title.toLowerCase() === path.toLowerCase());
    }
  }
  goToEditProfile(){
    this.navCtrl.navigateRoot('/profile/'+localStorage.getItem('user_id'));
  }

  getPermission(){
    this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.READ_PHONE_STATE
    ).then(res => {
      if(res.hasPermission){
        
      }else{
        this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_PHONE_STATE).then(res => {
          console.log(this.getID_UID('IMEI'));
          console.log("Persmission Granted Please Restart App!");
        }).catch(error => {
          console.log("Error! "+error);
        });
      }
    }).catch(error => {
      console.log("Error! "+error);
    });
  }

  getUniqueDeviceID() {
    this.uniqueDeviceID.get().then((uuid: any) => {
      console.log(uuid);
      this.UniqueDeviceID = uuid;
    }).catch((error: any) => {
      console.log(error);
      this.UniqueDeviceID = "Error! ${error}";
    });
  }


  getID_UID(type){
    if(type == "IMEI"){
      return this.uid.IMEI;
    }else if(type == "ICCID"){
      return this.uid.ICCID;
    }else if(type == "IMSI"){
      return this.uid.IMSI;
    }else if(type == "MAC"){
      return this.uid.MAC;
    }else if(type == "UUID"){
      return this.uid.UUID;
    }
  }

  logout(){
    localStorage.removeItem('user_id');
    localStorage.removeItem('token_type');
    localStorage.removeItem('access_token');
    if(!localStorage.getItem('user_id') && !localStorage.getItem('token_type') && !localStorage.getItem('access_token')){
        this.navCtrl.navigateRoot('/');
    }else{
        this.navCtrl.navigateRoot('/home');
     }
  }
}
