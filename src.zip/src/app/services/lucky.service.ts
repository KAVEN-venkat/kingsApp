import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { EnvService } from './env.service';
export interface OrderResponse {
  status: boolean;
  message:any;
  orders: string;
}

@Injectable({
  providedIn: 'root'
})
export class LuckyService {
	constructor(private http: HttpClient,private env: EnvService,
	) { 
		
	}
	createLuckyprice(itemId,prices) {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.post(this.env.API_URL + 'createLucky',{itemId: itemId,prices:prices}, { headers: headers });
		//return fname;
	}

	luckpriceLists(): Observable<OrderResponse> {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.get<OrderResponse>(this.env.API_URL + 'luckyPrice', { headers: headers }).pipe(tap(luckyprice => {
			return luckyprice;
		}));
	}

}
