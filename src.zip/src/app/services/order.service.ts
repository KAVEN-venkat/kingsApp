import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { EnvService } from './env.service';
export interface OrderResponse {
  status: boolean;
  message:any;
  orders: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
	constructor(private http: HttpClient,private env: EnvService,
	) { 
		
	}
	createOrder(category_id: Number, extra_price:String, item_digits: String, item_from: Number, item_id: Number, item_price: String, item_qty: Number, item_to: Number, sale_date: String, maxLength: Number) {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.post(this.env.API_URL + 'createOrder',{category_id: category_id, extra_price:extra_price, item_digits: item_digits, item_from: item_from, item_id: item_id, item_price: item_price, item_qty: item_qty, item_to: item_to, sale_date: sale_date, maxLength:maxLength}, { headers: headers });
		//return fname;
	}

	orderLists(limit): Observable<OrderResponse> {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		let url;
		if(limit == 'all'){
			url = this.env.API_URL + 'orders';
		}else{
			url =this.env.API_URL + 'orders/'+limit;
		}
		return this.http.get<OrderResponse>(url, { headers: headers }).pipe(tap(order => {
			return order;
		}));
	}

	orderByUser(userId): Observable<OrderResponse> {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		const url =this.env.API_URL + 'orderByUser/'+userId;
		return this.http.get<OrderResponse>(url, { headers: headers }).pipe(tap(order => {
			return order;
		}));
	}

	deleteOrder(orderId) {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.delete(this.env.API_URL + 'deleteOrder/'+orderId, { headers: headers }).pipe(tap(order => {
			return order;
		}));
	}
}
