import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { EnvService } from './env.service';

export interface WinnerResponse {
  status: boolean;
  message:any;
  winners: string;
}

@Injectable({
  providedIn: 'root'
})
export class WinnerService {
	constructor(private http: HttpClient,private env: EnvService,
	) { 
		
	}
	createWinner(winner_date,item_id,result_time,total_digits,winning_items) {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.post(this.env.API_URL + 'winner',{winner_date:winner_date,item_id:item_id,winning_items: winning_items,result_time:result_time,total_digits:total_digits}, { headers: headers });
		//return fname;
	}

	winnerLists(): Observable<WinnerResponse> {
		const headers = new HttpHeaders({
			'Authorization': localStorage.getItem('token_type')+" "+localStorage.getItem('access_token')
		});
		return this.http.get<WinnerResponse>(this.env.API_URL + 'winner', { headers: headers }).pipe(tap(winner => {
			return winner;
		}));
	}
}
