export class User {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    mobile:number;
    password: string;
	user_activation : string; 
	user_type : string;
	user_status : string;
	remember_token : string;
	created_at : string;
	updated_at : string;
}